Before running: pip install pandas matplotlib yfinance requests


After running the code the following commands can be used:
Transactions: type the transaction type with the ammount for example income 100, spent food 50, spent bills 50
Typing "balance" will display total expenses, income, balance of the spendings account(income-expenses), balance of the savings account and balance of stock portfolio 
Typing sp500 with time frame for example sp500 1d (d - day, m - month, y - year) will give the change in value over that time period.
for example buy sp500 1 or sell sp500 5 will count as transactions between your spendings account and investment portfolio.
savings +100 or savings -100 will transfer money between you spending balance and savings account
savings update will automaticaly move the excess money in your spendings account to the savings account
Ploting: plot with time frame will give you a pie chart with categories of income and expenses
plot savings with time frame will generate a graph of money in savings account over time
plot portfolio with time frame will generate a graph of money in the investment portfolio over time 
